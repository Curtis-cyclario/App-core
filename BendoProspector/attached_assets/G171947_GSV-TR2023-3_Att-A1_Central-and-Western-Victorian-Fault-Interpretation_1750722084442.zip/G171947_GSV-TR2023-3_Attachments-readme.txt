SKLADZIEN, P.B. & CAYLEY, R.A., 2023. Central-Western Victoria Regional Fault Data Package, Version 1.0. Geological Survey of Victoria Technical Record 2023/3. Department of Energy, Environment and Climate Action, 20 pp.

This report and data package at https://gsv.vic.gov.au/rid/171947

Licence: https://www.data.vic.gov.au/copyright

Formatted report
	G171947_GSV-TR2023-3_Central-Western-Victoria-Regional-Fault-Data-Package.pdf

Attachment A1 ESRI (G171947_GSV-TR2023-3_Att-A1_Central-and-Western-Victorian-Fault-Interpretation_ESRI.zip) - licenced software required ESRI™ Arcgis Pro or Arcmap 
	Data GDB gsv0197_central_west_victoria_fault_interp.gdb
	Symbology gsv0197_central_west_victoria_fault_mga54_v1_1.lyrx (Arcgis Pro 3.x), gsv0197_central_west_victoria_fault_mga54_v1_1.lyr (Arcmap 10.8)
	Fonts Geology GSV.ttf (copy/install to C:\Windows\Fonts) - do this first before opening lyr/lyrx/aprx
	Project gsv0197_central_west_victoria_fault_interp.aprx (Arcgis Pro)

Attachment A1 Open source (G171947_GSV-TR2023-3_Att-A1_Central-and-Western-Victorian-Fault-Interpretation.zip) - other GIS software required eg. MapInfo, QGIS (freeware)
	Data GDB gsv0197_central_west_victoria_fault_mga54.shp

	